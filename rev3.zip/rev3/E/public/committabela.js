var CommitTabela=(function(){

    var konstruktor=function(divElement,brojZadataka) {

        var tabela = document.createElement('table');
        const naslov = tabela.insertRow();
        const th1 = document.createElement('th');
        const textNode1 = document.createTextNode('Naziv zadatka');
        th1.appendChild(textNode1);
        const textNode2 = document.createTextNode('Commiti');
        const th2 = document.createElement('th');
        th2.appendChild(textNode2);
        naslov.appendChild(th1);
        naslov.appendChild(th2);
        
        for (var i = 0; i < brojZadataka; i++) {
            const red = tabela.insertRow();
            red.insertCell().innerHTML = 'Zadatak' + (i+1);
            red.insertCell();
        }
        divElement.appendChild(tabela);

        function obrisiPrazne() {
            for(let i = 0; i < tabela.rows.length; i++) {
                for(let j = 0; j < tabela.rows[i].cells.length; j++) {
                    if(tabela.rows[i].cells[j].childNodes.length === 0) {
                        tabela.rows[i].deleteCell(j);
                    }
                }
            }
        }

        function normalizuj() {
            obrisiPrazne();
            const max = nadjiNajveci();
            for(let i = 0; i < tabela.rows.length; i++) {
                const red = tabela.rows[i];
                const colspan = max - red.cells.length;
                if(red.cells.length < max) {
                    if(i === 0) {
                        red.cells[1].colSpan = colspan + 1;
                    } else {
                        red.insertCell().colSpan = colspan;
                    }
                }
            }
        }

        function nadjiNajveci() {
            let max = 0;
            for(let i = 0; i < tabela.rows.length; i++) {
                if(tabela.rows[i].cells.length > max) {
                    max = tabela.rows[i].cells.length;
                }
            }
            return max;
        }

        return{
            dodajCommit:function(rbZadatka,url){
                if(rbZadatka < 0 || rbZadatka + 1 > tabela.rows.length) {
                    return -1;
                }

                const red = tabela.rows[rbZadatka + 1];
                let rbCommita = 0;
                const linkNode = red.cells[red.cells.length - 1].childNodes[0];
                if(linkNode) {
                    rbCommita = Number(linkNode.innerHTML) + 1;
                } else {
                    rbCommita = red.cells.length - 1;
                }
                const celija = red.insertCell();
                const link = document.createElement('a');
                link.innerHTML = rbCommita;
                link.href = url;
                celija.appendChild(link);
                
                normalizuj();
            },      
            editujCommit:function(rbZadatka,rbCommita,url){
                if(rbZadatka < 0 || rbZadatka + 1 > tabela.rows.length || rbCommita < 0 || rbCommita+1 >= tabela.rows[rbZadatka+1].cells.length) {
                    return -1;
                }

                const staraCelija = tabela.rows[rbZadatka+1].cells[rbCommita+1];
                const stariLink = staraCelija.firstChild;

                const link = document.createElement('a');
                link.innerHTML = stariLink.innerHTML;
                link.href = url;

                const celija = tabela.rows[rbZadatka+1].cells[rbCommita+1];
                celija.removeChild(staraCelija.firstChild);
                celija.appendChild(link);

                normalizuj();
            },
            obrisiCommit:function(rbZadatka,rbCommita){
                if(rbZadatka < 0 || rbZadatka + 1 > tabela.rows.length || rbCommita < 0 || rbCommita+1 >= tabela.rows[rbZadatka+1].cells.length) {
                    return -1;
                }

                const red = tabela.rows[rbZadatka+1];
                red.deleteCell(rbCommita+1);
                normalizuj();
            }
        }
    }
return konstruktor;
}());
