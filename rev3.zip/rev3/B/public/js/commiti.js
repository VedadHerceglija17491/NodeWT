window.onload = function(){

    var mojDiv = document.getElementById('mojDiv');

    const rbCommita = document.getElementById('commit');
    const rbZadatka = document.getElementById('zadatak');;
    const url = document.getElementById('url');

    const dodaj = document.getElementById('buttonDodaj');
    const edituj = document.getElementById('buttonEdituj');
    const obrisi = document.getElementById('buttonObrisi');
    
    var tabela = new CommitTabela(mojDiv, 5);

    dodaj.addEventListener('click', function() {
        tabela.dodajCommit(Number(rbZadatka.value), url.value);
    });

    edituj.addEventListener('click', function() {
        tabela.editujCommit(Number(rbZadatka.value), Number(rbCommita.value), url.value);
    });

    obrisi.addEventListener('click', function() {
        tabela.obrisiCommit(Number(rbZadatka.value), Number(rbCommita.value));
    });

};