window.onload = function() {
    const form = document.getElementById('godina');
    const mojDiv = document.getElementById('glavniSadrzaj');
    var ga = new GodineAjax(mojDiv);
    
}
function klik() {
    var poruke = document.getElementById('poruke');
    var naziv = document.getElementsByName('nazivGod')[0];
    var vjezbe = document.getElementsByName('nazivRepVje')[0];
    var spirala = document.getElementsByName('nazivRepSpi')[0];

    const regex = /^[a-z]{1,}$/;
    
    validacija.godina(naziv);
    validacija.repozitorij(vjezbe, regex);
    validacija.repozitorij(spirala, regex);

    const valja = testiraj([naziv, vjezbe, spirala]);
    return valja;

}
function testiraj(inputs) {
    let valid = true;
    inputs.forEach(input => {
        if(input.style.backgroundColor === 'orangered'){
            valid = false;
        }
    });
    return valid;
}