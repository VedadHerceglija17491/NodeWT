var ZadaciAjax = (function() {
    var konstruktor = function(callbackFn) {
        var poziv = function(header) {
            var ajax = new XMLHttpRequest();
            
            ajax.ontimeout = function() {
                ajax.abort();
            }
            
            ajax.onreadystatechange = function() {
                if(ajax.readyState == 4) {
                    if(ajax.status == 200) {
                        var response = ajax.response;
                        callbackFn(response);
                    }
                    else {
                        callbackFn({greska: "Već ste uputili zahtjev!"});
                    }
                }
            }

            ajax.open('GET', 'http://localhost:8080/zadaci', true);
            ajax.setRequestHeader('Accept', header);
            ajax.timeout = 2000;
            ajax.send();
        }

        return {
            dajXML: function() {
                poziv("application/xml");
            },

            dajCSV: function() {
                poziv("text/csv");
            },
            dajJSON: function() {
                poziv("application/json");
            }
        };
    };
    return konstruktor;
}());