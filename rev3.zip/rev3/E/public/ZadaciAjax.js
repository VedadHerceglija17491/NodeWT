
//OSMI
var ZadaciAjax = (function () {
    var konstruktor = function (callbackFn) {
        var ima=false;
        vrijeme1 = new Date();
        return {
            dajXML: function () { 
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        ima=true;
                        var pom = xhttp.responseText;
                        callbackFn(pom);
                    }
                    else if(this.readyState == 4 && this.status == 404){
                        callbackFn({greska: "Vec ste uputili zahtjev"});
                    }
                };
                var url = "http://localhost:8080/zadaci";
                xhttp.open("GET", url, true);
                xhttp.setRequestHeader('Accept','application/xml');
                xhttp.send();
                var vrijeme2 = new Date();
                let ukupnoVrijeme=vrijeme2-vrijeme1;
                if(ukupnoVrijeme>2000){
                    alert("Greska");
                }
                
            },
            dajCSV: function () { 
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        ima=true;
                        var pom = xhttp.responseText;
                        callbackFn(pom);
                    }
                    else if(this.readyState == 4 && this.status == 404){
                        callbackFn({greska: "Vec ste uputili zahtjev"});
                    }
                };
                var url = "http://localhost:8080/zadaci";
                xhttp.open("GET", url, true);
                xhttp.setRequestHeader('Accept','application/csv');
                xhttp.send();
                var vrijeme2 = new Date();
                let ukupnoVrijeme=vrijeme2-vrijeme1;
                if(ukupnoVrijeme>2000){
                    alert("Greska");
                }
            },
            dajJSON: function () { 
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        ima=true;
                        var pom = xhttp.responseText;
                        callbackFn(pom);
                    }
                    else if(this.readyState == 4 && this.status == 404){
                        callbackFn({greska: "Vec ste uputili zahtjev"});
                    }
                };
                var url = "http://localhost:8080/zadaci";
                xhttp.open("GET", url, true);
                xhttp.setRequestHeader('Accept','application/json');
                xhttp.send();
                var vrijeme2 = new Date();
                let ukupnoVrijeme=vrijeme2-vrijeme1;
                if(ukupnoVrijeme>2000){
                    alert("Greska");
                }
            }
        }
    }
    return konstruktor;
}());
var zadaci = new ZadaciAjax(function funk(response){
    console.log(response);
});
zadaci.dajXML();