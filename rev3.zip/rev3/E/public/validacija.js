var Validacija=(function(){
    var poruka = '';
    var poruke = [];
    var konstruktor=function(divElementPoruke){
        function prikaziSvePoruke() {
            poruka = '';
            if(poruke.length > 0){
                poruka = 'Sljedeća polja nisu validna: ';
                poruke.forEach(function(naziv) {
                    poruka += naziv + ', ';
                });
                const duzina = poruka.length - 2;
                poruka = poruka.slice(0, duzina) + '!';
            }
            divElementPoruke.innerHTML = poruka;
        }

        function prikaziPoruku(inputElement) {
            const name = inputElement.getAttribute('name');
            const index = poruke.indexOf(name);
            if(index < 0) {
                poruke.push(name);
            }
            inputElement.style.backgroundColor = 'orangered';
            prikaziSvePoruke();
        }

        function ukloniPoruku(inputElement) {
            const name = inputElement.getAttribute('name');
            const index = poruke.indexOf(name);
            if(index >= 0) {
                poruke.splice(index, 1);
            }
            inputElement.style.removeProperty('background-color');
            prikaziSvePoruke();
        }
  
        return{
            ime: function(inputElement) {
                const regex = /^([A-Z]+([a-z]|[A-Z])*["|']?([a-z]|[A-Z])+["|']?([a-z]|[A-Z])+["|']?)$/;
                const value = inputElement.value;
                const rijeci = [];
                const rijeciSaCrticom = value.split(' ');
                rijeciSaCrticom.forEach(function(rijec) {
                    const nove = rijec.split('-');
                    rijeci.push(...nove);
                });
                let ispravne = true;
                rijeci.forEach(function(rijec) {
                    if(!regex.test(rijec)) {
                        ispravne = false;
                    }
                });

                if(ispravne) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            godina: function(inputElement) {
                const value = inputElement.value;
                const godine = value.split('/');
                let ispravne = false;
                if(godine.length === 2){
                    const godina1 = Number(godine[0]);
                    const godina2 = Number(godine[1]);
                    if(godina1 >= 2000 && godina1 <= 2098 &&
                        godina2 > godina1 && godina2 <= 2099 && godina2 - godina1 === 1) {
                            ispravne = true;
                        }
                }
                
                if(ispravne) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            repozitorij: function(inputElement, regex) {
                const value = inputElement.value;
                const ispravan = regex.test(value);
                if(ispravan) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            index: function(inputElement) {
                const value = inputElement.value;
                const regex = /^\d{5}$/;
                let ispravan = false;
                let jeBroj = regex.test(value);
                if(jeBroj) {
                    const broj = Number(value);
                    ispravan = jeBroj && broj >= 14000 && broj <= 20999;
                }
                if(ispravan) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            naziv: function(inputElement) {
                const regex = /^(([a-z]|[A-Z])+([A-Z]|[a-z]|\d|[\\]|\/|-|"|'|!|\?|:|;|,)+([a-z]|[0-9])+)$/;
                const value = inputElement.value;
                const ispravan = regex.test(value);
                if(ispravan) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            password: function(inputElement) {
                const regex = /^(((?=.*[a-z])|(?=.*[A-Z]))(?=.*\d)|(?=.*[a-z])((?=.*[A-Z])|(?=.*\d))|(?=.*[A-Z])(((?=.*[a-z]))|(?=.*\d)))[a-zA-Z\d]{8,}$/;
                const value = inputElement.value;
                const ispravan = regex.test(value);
                if(ispravan) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            },
            url: function(inputElement) {
                const regex = /^(https|http|ftp|ssh):\/\/\w+((\w+(?!\.))|(\.\w+)*)(\/(\w+\/?)+\??([a-z\d\-]\=[a-z\d\-]\&[a-z\d\-]\=[a-z\d\-])?)?/;
                const value = inputElement.value;
                const ispravan = regex.test(value);
                if(ispravan) {
                    ukloniPoruku(inputElement);
                } else {
                    prikaziPoruku(inputElement);
                }
            }
        }
    }
    return konstruktor;
}());