window.onload = function() {
    const form = document.getElementById('fPojedinacni');
    form.onsubmit = function(event) {
        event.preventDefault();
    }
}
function klik() {
    var poruke = document.getElementById('poruke');
    var ime = document.getElementsByName('ime')[0];
    var index = document.getElementsByName('indeks')[0];

    index.style.removeProperty('background-color');

    var validacija = new Validacija(poruke);

    validacija.ime(ime);
    validacija.index(index);
};