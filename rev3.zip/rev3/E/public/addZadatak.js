window.onload = function() {
    const form = document.getElementById('form');
    
}
function klik() {
    var poruke = document.getElementById('poruke');
    var naziv = document.getElementsByName('naziv')[0];

    var validacija = new Validacija(poruke);

    validacija.naziv(naziv);
};