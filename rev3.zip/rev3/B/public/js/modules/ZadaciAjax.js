var ZadaciAjax = (function () {
    let inUse = false;
    var konstruktor = function (callbackFn) {
        const dajXML = function() {
            if(inUse) {
                callbackFn({greska: 'Već ste uputili zahtjev'});
                return;
            }
            let answered = false;
            const ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    inUse = false;
                    answered = true;
                    const xmlZadaci = ajax.responseText;
                    callbackFn(xmlZadaci);
                }
            }

            ajax.open('GET', 'http://localhost:8080/zadaci', true);
            ajax.setRequestHeader('Accept', 'application/xml');
            ajax.send();
            inUse = true;
            setTimeout(function() {
                if(!answered) {
                    ajax.abort();
                    inUse = false;
                }
            }, 2000);
        }
        const dajCSV = function() {
            if(inUse) {
                callbackFn({greska: 'Već ste uputili zahtjev'});
                return;
            }
            let answered = false;
            const ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    inUse = false;
                    answered = true;
                    const csvZadaci = ajax.responseText;
                    callbackFn(csvZadaci);
                }
            }

            ajax.open('GET', 'http://localhost:8080/zadaci', true);
            ajax.setRequestHeader('Accept', 'text/csv');
            ajax.send();
            inUse = true;
            setTimeout(function() {
                if(!answered) {
                    ajax.abort();
                    inUse = false;
                }
            }, 2000);
        } 
        const dajJSON = function() {
            if(inUse) {
                callbackFn({greska: 'Već ste uputili zahtjev'});
                return;
            }
            let answered = false;
            const ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    inUse = false;
                    answered = true;
                    const jsonZadaci = JSON.parse(ajax.responseText);
                    callbackFn(jsonZadaci);
                }
            }

            ajax.open('GET', 'http://localhost:8080/zadaci', true);
            ajax.setRequestHeader('Accept', 'application/json');
            ajax.send();
            inUse = true;
            setTimeout(function() {
                if(!answered) {
                    ajax.abort();
                    inUse = false;
                }
            }, 2000);
        } 
        return {
            dajXML: dajXML,
            dajCSV: dajCSV,
            dajJSON: dajJSON
        }
    }
    return konstruktor;
}());