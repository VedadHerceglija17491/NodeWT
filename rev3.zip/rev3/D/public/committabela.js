function nekaFunkcija() {
    alert("ovo je poruka");
}

var CommitTabela = (function() {
    
    var konstruktor = function(divElement, brojZadataka){

        var ispravljanjeRedova = function() {
            var tabela = document.getElementById("commiti");
            var sviRedovi = tabela.getElementsByTagName("tr");
            var maxCommita = findMaxCells() - 1;

            for(var i = 0; i < sviRedovi.length; i++) {
                if(i == 0) {
                    var heading = sviRedovi[0].getElementsByTagName("th")[1];
                    heading.colSpan = maxCommita;
                }
                else {
                    var celijeReda = sviRedovi[i].getElementsByTagName("td");
                    if(celijeReda.length - 1 < maxCommita) {
                        for(var j = 1; j < celijeReda.length; j++) {
                            if(celijeReda[j].innerHTML == "") {
                                celijeReda[j].colSpan = maxCommita - celijeReda.length + 2;
                                break;
                            }
                            else if(j == celijeReda.length - 1) {
                                sviRedovi[i].innerHTML += '<td></td>';
                            }
                        }
                    }
                }
            }

        }
        
        if(!document.getElementById("commiti")) {
            divElement.innerHTML = '<table id="commiti"><tr><th>Naziv zadatka</th><th colspan="1">Commiti</th></tr></table>';
        
            var tabela = document.getElementById("commiti");

            for(var i = 0; i < brojZadataka; i++) {
                var string = "Zadatak " + (i+1);
                tabela.innerHTML += '<tr><td>' + string + '</td> <td></td></tr>';
            
            }

            divElement.innerHTML += "</table>";

        }
        return {
            dodajCommit: function(rbZadatka, url) {
                var tabela = document.getElementById("commiti");

                var nadjiPraznuCeliju = function(celije) {
                    //pocinje od 1 jer je celije[0] == "Zadatak x"
                    for(var i = 1; i < celije.length; i++) {
                        var jedna = celije[i];
                        if(jedna.innerHTML == "") {
                            return { nadjenaPrazna: true, indexPrazneCelije: i };
                        }
                    }

                    return { nadjenaPrazna: false, brojCommitaURedu: (celije.length - 1) };
                }

                var odredjeniRed = tabela.getElementsByTagName("tr")[rbZadatka];
                var celijeReda = odredjeniRed.getElementsByTagName("td");
                //var brojCelija = odredjeniRed.getElementsByTagName("td").length;

                var prazneCelije = nadjiPraznuCeliju(celijeReda);
                
                if(prazneCelije.nadjenaPrazna) {
                    //nadjena je prazna celija u redu, u nju se upisuje novi commit
                    var indexCelije = prazneCelije.indexPrazneCelije;
                    
                    var brojCommita = -1;
                    if(indexCelije != 1)
                        brojCommita = parseInt(celijeReda[indexCelije-1].getElementsByTagName("a")[0].innerHTML, 10)  + 1;
                    else 
                        brojCommita = 1;

                    celijeReda[indexCelije].innerHTML = '<a href="' + url + '">' + brojCommita + '</a>';
                    celijeReda[indexCelije].colSpan = 1;   
                    
                    var najviseCommita = findMaxCells() - 1;
                    var brojTrenutnihCommita = odredjeniRed.getElementsByTagName("td").length - 1;
                    var colspanCelije = najviseCommita - brojTrenutnihCommita;
                    if(colspanCelije != 0)
                        odredjeniRed.innerHTML += '<td colSpan="' + colspanCelije + '"></td>';
                }
                else {
                    //nije nadjena prazna celija u redu, dodaje se nova + provjera svih redova
                    
                    var brojCommita = parseInt(celijeReda[celijeReda.length-1].getElementsByTagName("a")[0].innerHTML,10) + 1;
                    
                    odredjeniRed.innerHTML += '<td><a href="' + url + '">' + brojCommita + '</a></td>';
                }   
                ispravljanjeRedova();  
            },
            
            editujCommit: function(rbZadatka, rbCommita, url) {
                var tabela = document.getElementById("commiti");
                var redovi = tabela.getElementsByTagName("tr");

                if(rbZadatka <= 0 || rbZadatka > (redovi.length-1)) return -1;
                
                var odredjeniRed = redovi[rbZadatka];
                var commitiReda = odredjeniRed.getElementsByTagName("td");
                    //ako je rbCommita vise nego sto ima commita (celija) u redu
                    //ako je rbCommita <= 0
                if(rbCommita <= 0) return -1;
                //pocinje od 1 jer je commitiReda[0] = "Zadatak x"
                var found = false;
                for(var i = 1; i < commitiReda.length; i++) {
                    if(commitiReda[i].innerHTML.includes(rbCommita)) {
                        found = true;
                        break;
                    }
                }
                    //ako nije nadjen taj commit u redu
                if(!found) return -1;
                 
                var odredjeniCommit = commitiReda[rbCommita];
                odredjeniCommit.innerHTML = '<a href="' + url + '">' + rbCommita + '</a>';
                
                return 0;
            },

            obrisiCommit:function(rbZadatka,rbCommita) {
                var tabela = document.getElementById("commiti");
                var redovi = tabela.getElementsByTagName("tr");
                if(rbZadatka >= redovi.length) return -1;

                var odredjeniRed = redovi[rbZadatka];
                var commitiReda = odredjeniRed.getElementsByTagName("td");
                    //ista logika kao u editujCommit
                    //to moze u samo jednuuu funkcijuuuu
                    //rb commita MOZE biti veci od commitiReda.length
                if(rbCommita <= 0) return -1;
                    //pocinje od 1 jer je commitiReda[0] = "Zadatak x"
                var found = false;
                for(var i = 1; i < commitiReda.length; i++) {
                    if(commitiReda[i].innerHTML.includes(rbCommita)) {
                        found = true;
                        break;
                    }
                }
                    //ako nije nadjen taj commit u redu
                if(!found) return -1;

                for(var i = 1; i < commitiReda.length; i++) {
                    var pojediniCommit = commitiReda[i];
                    if(pojediniCommit.innerHTML.includes(rbCommita)) {
                        //ovaj se brise
                        pojediniCommit.parentNode.removeChild(pojediniCommit);
                        break;
                    }
                }

                ispravljanjeRedova();
            }
        }
    }   
    
    return konstruktor;
}());

window.onload = function() {
    
var divTabele = document.getElementsByClassName("table")[0];

var tabela = new CommitTabela(divTabele, 0);
//tabela();

}