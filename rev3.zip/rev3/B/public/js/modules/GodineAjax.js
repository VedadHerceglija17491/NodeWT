var GodineAjax = (function () {
    var konstruktor = function (divSadrzaj) {

        const osvjezi = function () {
            const ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    const jsonNizGodina = JSON.parse(ajax.responseText);
                    let godine = ''; 
                    jsonNizGodina.forEach(godina => {
                        godine += `<div class="godina">
                                        <span>${godina.nazivGod}</span>
                                        <p><b>Vjezbe:</b> ${godina.nazivRepVje}</p>
                                        <p><b>Broj vježbi:</b> ${godina.nazivRepSpi}</p>
                                    </div>`;
                    });
                    divSadrzaj.innerHTML = godine;
                } else {
                    divSadrzaj.innerHTML = 'Doslo je do greske!';
                }
            }

            ajax.open('GET', 'http://localhost:8080/godine', true);
            ajax.send();
        }

        osvjezi();

        return {
            osvjezi: osvjezi
        }
    }
    return konstruktor;
}());