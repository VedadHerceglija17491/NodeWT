const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
var path = require("path");

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "public/views"));

//multer se koristi u drugom zadatku
const multer = require('multer');
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'public/pdf');
    },
    filename: function(req, file, cb) {
        cb(null, req.body.naziv + ".pdf");
    }
});
const upload = multer({ 
    storage : storage,
    fileFilter : function(req, file , cb) {
        var ext = file.mimetype;
        if(!ext.includes("pdf"))
            return cb(new Error("Dozvoljeni su samo pdf fajlovi"));

        var params = req.body.naziv;
        fs.readFile(__dirname + "\\public\\pdf\\" + params + "Zad.json", function(err, content) {
            if(content != undefined) 
                return cb(new Error("Zadatak sa tim imenom vec postoji"));
            
            cb(null, true);
        });
    }
 }).single("postavka");

//PRVI ZADATAK
app.use(express.static("public"));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//DRUGI ZADATAK
app.post("/addZadatak", function(req, res) {
    upload(req, res, function(err) {
        if(err) {
            //error
            res.render('greska', { porukaGreske: err.message, link: "http://localhost:8080/addZadatak.html"  });
        }
        else {
            //ispravno
            var name = req.file.filename.slice(0,-4);
            var encoded = encodeURI(name);
            var link = "http://localhost:8080/pdf/" + encoded + ".pdf";
            var content = { naziv: name, postavka: link};
            var fileName = name + "Zad.json";
            fs.appendFile("public\\pdf\\" + fileName, JSON.stringify(content), function(err) {
                res.sendFile(__dirname + "\\public\\addZadatak.html");
            });
        }
    });
});

//TRECI ZADATAK
app.get("/zadatak", function(req, res){
    var params = req.query.naziv;
    fs.readFile(__dirname + "\\public\\pdf\\" + params + "Zad.json", function(err, content) {
        if(err)     
            res.sendFile(__dirname + "\\public\\greska.html");
        if(content == undefined) res.sendFile(__dirname + "\\public\\greska.html");
        else {
            var json = JSON.parse(content);
            var link = json["postavka"];
            res.redirect(link);
        }
    });
});

//CETVRTI ZADATAK
app.post('/addGodina', function(req, res) {
    var params = req.body;
    var godina = params["nazivGod"];
    var repV = params["nazivRepVje"];
    var repS = params["nazivRepSpi"];

    fs.readFile(__dirname + "\\public\\godine.csv", function(err, content) {
        if(err)
            res.sendFile(__dirname + "\\public\\greska.html");
        var file = content.toString();
        if(file.includes(godina.toString())) {
            var message = "Ta godina je vec upisana";
            res.render('greska', { porukaGreske: message, link: "http://localhost:8080/addGodina.html" });
        }
        else {
            var final = "";
            if(file != "") final = "\n";
            final += godina + "," + repV + "," + repS;
            fs.appendFile(__dirname + "\\public\\godine.csv", final, function(err){
                if(err) throw err;
                res.sendFile(__dirname + "\\public\\addGodina.html");
            });
        }
    });
});

//PETI I SESTI ZADATAK
app.get('/godine', function(req, res) {
    fs.readFile(__dirname + "\\public\\godine.csv", function(err, content) {
        if(err)
            res.sendFile(__dirname + "\\public\\greska.html");
        if(content.toString() != "") {
            var redovi = content.toString().split('\n');
            var result = [];
            for(var i = 0; i < redovi.length; i++) {
                var kolone = redovi[i].split(',');
                var novi = { nazivGod: kolone[0], nazivRepVje: kolone[1], nazivRepSpi: kolone[2] };
                result.push(novi);
            }
            res.send(result);
        }
        else 
            res.send([]);
    });
});

//SEDMI ZADATAK
//ps. ima viska/duplog koda
app.get('/zadaci', function(req, res) {
    var format = req.headers['accept'].toString();
    //ako je accept samo */* tad se vraca json

    
    if(format.includes("application/json") || format == "*/*") {
        // json 
        fs.readdir(__dirname + "\\public\\pdf", function(err, files) {
            var brojZadataka = files.length;
            var result = [];
            //prolazi kroz sve zadatke
            for(var i = 0; i < brojZadataka; i++) {
                var pomocna = (function() {
                    var dot = files[i].lastIndexOf('.');
                    var ext = files[i].split('.').pop();
                    var zad = files[i].slice(dot - 3, dot);
                    //provjera da li je ekstenzija '.json' i da li se fajl zavrsava na 'Zad' odn. da li je fajl sa postavkom zaista nazvan kao "NazivZadatkaZad.json"
                    if(ext == "json" && zad == "Zad") {
                        var imeFajla = files[i];
                        return imeFajla.slice(0, -8);
                    }
                    else throw new Error("Nije json");
                });

                try {
                    var naziv = pomocna();
                    var link = encodeURI(naziv);
                    var postavka = "http://localhost:8080/pdf/" + link + ".pdf";
                    var temp = { naziv: naziv, postavka: postavka};
                    result.push(temp);
                }
                catch(error) { }
            }
            res.send(result);
        });
    }
    else if(format.includes("application/xml") || format.includes("text/xml")){
        // XML

        fs.readdir(__dirname + "\\public\\pdf", function(err, files) {
            var brojZadataka = files.length;
            var result = '<?xml version="1.0" encoding="UTF-8"?><zadaci>'
            //prolazi kroz sve zadatke
            for(var i = 0; i < brojZadataka; i++) {
                var pomocna = (function() {
                    var dot = files[i].lastIndexOf('.');
                    var ext = files[i].split('.').pop();
                    var zad = files[i].slice(dot - 3, dot);
                    if(ext == "json" && zad == "Zad") {
                        var imeFajla = files[i];
                        return imeFajla.slice(0, -8);
                    }
                    else throw new Error("Nije json");
                });

                try {
                    var naziv = pomocna();
                    var link = encodeURI(naziv);
                    var postavka = "http://localhost:8080/pdf/" + link + ".pdf";
                    var temp = "<zadatak><naziv>" + naziv + "</naziv><postavka>" + postavka + "</postavka></zadatak>"
                    result += temp;
                }
                catch(error) { }
            }
            result += "</zadaci>";
            res.type("application/xml");
            res.send(result);
        });
    }
    else if(format.includes("text/csv")) {
        // CSV

        fs.readdir(__dirname + "\\public\\pdf", function(err, files) {
            var brojZadataka = files.length;
            var result = "";
            //prolazi kroz sve zadatke
            for(var i = 0; i < brojZadataka; i++) {
                var pomocna = (function() {
                    var dot = files[i].lastIndexOf('.');
                    var ext = files[i].split('.').pop();
                    var zad = files[i].slice(dot - 3, dot);
                    //provjera da li je ekstenzija '.json' i da li se fajl zavrsava na 'Zad' odn. da li je fajl sa postavkom zaista nazvan kao "NazivZadatkaZad.json"
                    if(ext == "json" && zad == "Zad") {
                        var imeFajla = files[i];
                        return imeFajla.slice(0, -8);
                    }
                    else throw new Error("Nije json");
                });
                try {
                    var naziv = pomocna();
                    var link = encodeURI(naziv);
                    var postavka = "http://localhost:8080/pdf/" + link + ".pdf";
                    var temp = naziv + "," + postavka + "\r"
                    result += temp;
                }
                catch(error) { }
            }
            res.send(result.trimRight());
        });
    }
});



app.listen(8080);