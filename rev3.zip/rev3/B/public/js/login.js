function klik() {
    var porukeDiv = document.getElementById('poruke');
    var password = document.getElementsByName('password')[0];

    var validacija = new Validacija(porukeDiv);

    validacija.password(password);
};