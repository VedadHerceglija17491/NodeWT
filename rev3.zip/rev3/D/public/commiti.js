function findMaxCells() {
    var tabela = document.getElementById("commiti");
    var redovi = tabela.getElementsByTagName("tr");
    if(redovi.length == 1) return 2;
    var brojac = 0;
    for(var i = 1; i < redovi.length; i++) {
        if(brojac < redovi[i].getElementsByTagName("td").length) 
            brojac = redovi[i].getElementsByTagName("td").length;
    }
    return brojac;
}

function dodajZadatak() {
    var tabela = document.getElementById("commiti");
    var brojac = findMaxCells() - 1;
    tabela.innerHTML += '<tr><td>Zadatak ' + tabela.getElementsByTagName("tr").length + '</td><td colspan="' + brojac + '"></td></tr>';  
}

function dodajCommitSecond() {
    var nesto = CommitTabela();
    var inputZadatak = document.getElementById("brojZadatka");
    var brojZadataka = document.getElementById("commiti").getElementsByTagName("tr").length;
    if(inputZadatak.value > 0 && inputZadatak.value < brojZadataka) {
        var inputUrl = document.getElementById("unosURL");
        var url = inputUrl.value;
        if(validiraj() == 0)
            nesto.dodajCommit(inputZadatak.value, url);
    }
    else 
        alert("Neispravan redni broj zadatka");
}

function editCommitSecond() {
    var nesto = CommitTabela();
    
    var inputZadatak = document.getElementById("brojZadatka");
    var inputUrl = document.getElementById("unosURL");
    var inputCommit = document.getElementById("brojCommita");

    var temp = nesto.editujCommit(inputZadatak.value, inputCommit.value, inputUrl.value);
    if(temp == -1) 
        alert("Neispravni parametri");
}

function obrisiCommitSecond() {
    var nesto = CommitTabela();

    var inputZadatak = document.getElementById("brojZadatka");
    var inputCommit = document.getElementById("brojCommita");

    var temp = nesto.obrisiCommit(inputZadatak.value, inputCommit.value);
    if(temp == -1) 
        alert("Neispravni parametri");
}

function validiraj() {
    var inputUrl = document.getElementById("unosURL");
    var divGreske = document.getElementById("divGreske");

    var novo = Validacija(divGreske);
    return novo.url(inputUrl);
}