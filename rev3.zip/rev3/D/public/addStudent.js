function validirajPrvu() {
   var formClass = document.getElementsByClassName("formClass")[0];
    var fPojedinacni = formClass.getElementsByTagName("form")[0];
   
    var selectGodina = fPojedinacni.getElementsByTagName("select")[0];
    var inputIme = fPojedinacni.getElementsByTagName("input")[0];
    var inputIndex = fPojedinacni.getElementsByTagName("input")[1];
    
    var divGreske = document.getElementsByClassName("divGreske")[0];

    var novo = Validacija(divGreske);

    var validacijaGodine = novo.godina(selectGodina);
    var validacijaImena = novo.ime(inputIme);
    var validacijaIndexa = novo.index(inputIndex);
}

//ovo je zapravo nepotrebno jer select nije vrsta input field-a?
function validirajDrugu() {
    var formClass = document.getElementsByClassName("formClass")[1];
    var fMasovni = formClass.getElementsByTagName("form")[0];

    var selectGodina = fMasovni.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[1];
    Validacija(divGreske).godina(selectGodina);
}