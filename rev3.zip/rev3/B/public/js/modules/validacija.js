var Validacija=(function(){
    var errorMessage = '';
    var errorInputs = [];
    var konstruktor=function(divElementPoruke){
        function error() {
            errorMessage = '';
            if(errorInputs.length > 0){
                errorMessage = 'Sljedeća polja nisu validna: ';
                errorInputs.forEach(function(error) {
                    errorMessage += error + ', ';
                });
                const length = errorMessage.length - 2;
                errorMessage = errorMessage.slice(0, length) + '!';
            }
            divElementPoruke.innerHTML = errorMessage;
        }

        function validate(inputElement, expression) {
            const name = inputElement.getAttribute('name');
            const index = errorInputs.indexOf(name);
            if(expression) {
                if(index >= 0) {
                    errorInputs.splice(index, 1);
                }
                inputElement.setAttribute('style', '');
            } else {
                if(index < 0) {
                    errorInputs.push(name);
                }
                inputElement.setAttribute('style', 'background-color: orangered');
            }
            error();
        }

        var ime = function(inputElement) {
            const regex = /^(([A-Z]+[a-z]*("|')?[a-z]+("|')?[a-z]*(-|\s)?)){1,4}$/g;
            const value = inputElement.value;
            
            validate(inputElement, regex.test(value));
        }

        var godina = function(inputElement) {
            const value = inputElement.value;
            const godine = value.split('/');
            const expression1 = godine && godine.length === 2;
            const godina1 = Number(godine[0]);
            const godina2 = Number(godine[1]);
            const expression2 = godina1 >= 2000 && godina1 <= 2098 &&
                                godina2 > godina1 && godina2 <= 2099 && godina2 - godina1 === 1;
            validate(inputElement, expression1 && expression2);
        }

        var repozitorij = function(inputElement, regex) {
            const value = inputElement.value;
            validate(inputElement, regex.test(value));
        }

        var index = function(inputElement) {
            const value = inputElement.value;
            const regex = /^\d{5}$/;
            let expression = regex.test(value);
            if(expression) {
                const num = Number(value);
                expression = expression && num >= 14000 && num <= 20999;
            }
            validate(inputElement, expression);
        }

        var naziv = function(inputElement) {
            const regex = /^(([a-z]|[A-Z])+([A-Z]|[a-z]|\d|[\\]|\/|-|"|'|!|\?|:|;|,)+([a-z]|[0-9])+)$/;
            const value = inputElement.value;
            validate(inputElement, regex.test(value));
        }

        var password = function(inputElement) {
            const regex = /^(((?=.*[a-z])|(?=.*[A-Z]))(?=.*\d)|(?=.*[a-z])((?=.*[A-Z])|(?=.*\d))|(?=.*[A-Z])(((?=.*[a-z]))|(?=.*\d)))[a-zA-Z\d]{8,}$/;
            const value = inputElement.value;
            validate(inputElement, regex.test(value));
        }

        var url = function(inputElement) {
            const regex = /^(https|http|ftp|ssh):\/\/\w+((\w+(?!\.))|(\.\w+)*)(\/(\w+\/?)+\??([a-z\d\-]\=[a-z\d\-]\&[a-z\d\-]\=[a-z\d\-])?)?/;
            const value = inputElement.value;
            validate(inputElement, regex.test(value));
        }
        
        return{
            ime: ime,
            godina: godina,
            repozitorij: repozitorij,
            index: index,
            naziv: naziv,
            password: password,
            url: url
        }
    }
    return konstruktor;
}());