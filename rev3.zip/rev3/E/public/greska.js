function Nazad()
{
    //console.log("DISIJFJSHDFJCS");
    window.history.back();
}