const express = require('express');
const bodyParser = require('body-parser');

const fs = require('fs');
const app = express();
const multer  = require('multer')
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, __dirname + '/public');
    },
    filename: function (req, file, cb) {
        cb(null, req.body['naziv'] + ".pdf");
    }
});

var upload = multer(
    { 
        storage: storage, 
        fileFilter: function (req, file, cb) {
           
            if (file.originalname.substr(file.originalname.length - 4) !== '.pdf' || fs.existsSync(__dirname + '/public/' + req.body['naziv'] + '.pdf')) {
                cb(null, false);
                return;
            }

            cb(null, true)
        }
    });

app.use(express.static(__dirname + "/public"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//1. zadatak
app.get('/addGodina.html',function(req,res){
    res.sendFile('addGodina.html', {"root": "public"});
});
app.get('/addStudent.html',function(req,res){
    res.sendFile('addStudent.html', {"root": "public"});
});
app.get('/addVjezba.html',function(req,res){
    res.sendFile('addVjezba.html', {"root": "public"});
});
app.get('/addZadatak.html',function(req,res){
    res.sendFile('addZadatak.html', {"root": "public"});
});
app.get('/commit.html',function(req,res){
    res.sendFile('commit.html', {"root": "public"});
});
app.get('/login.html',function(req,res){
    res.sendFile('login.html', {"root": "public"});
});
app.get('/studenti.html',function(req,res){
    res.sendFile('studenti.html', {"root": "public"});
});
app.get('/zadaci.html',function(req,res){
    res.sendFile('zadaci.html', {"root": "public"});
});

//2. zadatak
app.post('/addZadatak', upload.single('postavka'), function(req,res){

    let parametri = req.body;
    
    if(fs.existsSync(__dirname + '/public/' + parametri['naziv'] + 'Zad' + '.json'))
    {
        
        res.sendFile('greska.html', {"root": "public"});
        return;
    }
    else
    {
        var a = req.file;
        var data = {naziv:parametri['naziv'], postavka:"http://localhost:8080/" + encodeURI(parametri['naziv']) + '.pdf'};
        data = JSON.stringify(data);
        fs.writeFile("public/" + encodeURI(parametri['naziv']) + "Zad.json", data, (err) => {
            if (err) {
            }
        });

        res.sendFile('addZadatak.html', {"root": "public"});
    }
    
    
});

//3. zadatak
app.get('/zadatak',function(req,res){
    //var mojURL = req.url;
    var pdf = req.query['naziv'];
    pdf = decodeURIComponent(pdf);
    var extension = pdf.substr(pdf.length - 4);
    if(extension != ".pdf") {
        pdf = pdf + ".pdf";
    }
    res.sendFile(pdf, {"root": __dirname + "/public"});
});

//4. zadatak
app.post('/addGodina',function(req,res) {
    
    let parametri = req.body;
    //je li poslan zahtjev sa forme
    
    let novaLinija = parametri['nazivGod']+","+parametri['nazivRepVje']
        +","+parametri['nazivRepSpi'];

    //postoji li datoteka već?
    fs.readFile(__dirname + '/public/godine.csv',function(err,content) {
        var postoji = true;
        if(err) {
            //ako je code ENOENT to znaci da fajl ne postoji
            if(err.code != "ENOENT") {
                res.writeHead(404,{"Content-Type":"application/json"});
                res.end(JSON.stringify({message:'404 Not Found'}));
                return;
            }
            postoji = false;
        }
        if(postoji) {
            novaLinija = "\n" + novaLinija;
        }
        var tekst = content.toString();
        var redovi = tekst.split("\n");
        for(var j = 0; j < redovi.length-1; j++) {
            var kolone = redovi[j].split(",");
            if(kolone[0] == parametri['nazivGod']) {
                //naziv godine vec postoji u datoteci
                res.sendFile("greska.html", {"root": __dirname + "/public"});
                return;
            }
        }
        fs.appendFile(__dirname + '/public/godine.csv', novaLinija, function(err) {
            if(err) throw err;
            
            fs.readFile(__dirname + '/public/godine.csv',function(err,content) {
                if(err) {
                    res.writeHead(404,{"Content-Type":"application/json"});
                    res.end(JSON.stringify({message:'404 Not Found'}));
                    return;  
                }
                res.status(200);
                res.contentType("text/html");
                res.sendFile("addGodina.html", {"root": __dirname + "/public"});
            });
        });
    });
    
});

//5. zadatak
app.get('/godine',function(req, res){
    fs.readFile(__dirname + '/public/godine.csv',function(err,content) {
       
        if(err) {
            res.writeHead(404,{"Content-Type":"application/json"});
            res.end(JSON.stringify({message:'404 Not Found'}));
            return;  
        }
        var data = [];
        var tekst = content.toString();
        var redovi = tekst.split("\n");
        for(var i = 0; i < redovi.length; i++) {
            var kolone = redovi[i].split(",");
            var objekat = {nazivGod:kolone[0],nazivRepVje:kolone[1],nazivRepSpi:kolone[2]};
            data.push(objekat);
        }
        var odgovor = JSON.stringify(data)
        res.writeHead(200,{"Content-Type":"application/json"});
        res.end(odgovor);
    }); 
});

//7. zadatak
app.get('/zadaci',function(req, res){
    if(req.accepts('text/json') || req.accepts('application/json'))
    {
        var izlaz;
        fs.readdir(__dirname + "/public", (err, files) => {
            var json = [];
            files.forEach(file => {
                if(file.substr(file.length - 4) == ".pdf")
                {
                    json.push({naziv:file.substr(0, file.length - 4), postavka:'http://localhost:8080/' + encodeURI(file)});
                }
            });
            izlaz = json;
            res.writeHead(200,{"Content-Type":"application/json"});
            res.end(JSON.stringify(json));
        });
        
        
    }
    else if(req.accepts('text/xml') || req.accepts('application/xml'))
    {
        
        fs.readdir(__dirname + "/public", (err, files) => {
            var xml = '<?xml version="1.0" encoding="UTF-8"?><zadaci>';
            files.forEach(file => {
                if(file.substr(file.length - 4) == ".pdf")
                {
                    xml = xml + "<zadatak><naziv>" + file.substr(0, file.length - 4) + "</naziv><postavka>http://localhost:8080/" 
                    + file + "</postavka></zadatak>";
                }
            });
            xml = xml + "</zadaci>";
            
            res.writeHead(200,{"Content-Type":"application/xml"});
            res.end(xml);
        })
        
    }
    else if(req.accepts('text/csv') || req.accepts('application/csv'))
    {
        
        fs.readdir(__dirname + "/public", (err, files) => {
            var csv = "";
            files.forEach(file => {
                if(file.substr(file.length - 4) == ".pdf")
                {
                   csv = csv + file.substr(0, file.length - 4) + ",http://localhost:8080/" 
                    + file + "\n";
                }
            });
            res.writeHead(200,{"Content-Type":"application/csv"});
            res.end(csv);
        });
       
    }
});

app.listen(8080);