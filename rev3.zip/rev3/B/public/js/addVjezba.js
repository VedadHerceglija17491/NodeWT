window.onload = function() {
    const form = document.getElementsByName('fNova')[0];
    form.onsubmit = function(event) {
        event.preventDefault();
    }
}
function klik() {
    var porukeDiv = document.getElementById('poruke');
    var naziv = document.getElementsByName('naziv')[0];

    var validacija = new Validacija(porukeDiv);

    validacija.naziv(naziv);
};