function validirajPrvu() { // ovo je nepotrebno ?
    var formClass = document.getElementsByClassName("formClass")[0];
    var fPostojeca = formClass.getElementsByTagName("form")[0];

    var selectGodina = fPostojeca.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[0];
    Validacija(divGreske).godina(selectGodina);
}

function validirajDrugu() { 
    var formClass = document.getElementsByClassName("formClass")[1];
    var fNova = formClass.getElementsByTagName("form")[0];

    var inputNaziv = fNova.getElementsByTagName("input")[0];
    var selectGodina = fNova.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[1];

    var novo = Validacija(divGreske);
    var validacijaNaziva = novo.naziv(inputNaziv);
    var validacijaGodine = novo.godina(selectGodina);
}