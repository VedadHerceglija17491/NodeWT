var GodineAjax = (function(){
    var konstruktor = function(divSadrzaj){
        
        var ajax=new XMLHttpRequest();
        ajax.onreadystatechange=function(){
            
            if(ajax.readyState==4 && ajax.status==200){
                
                var arr = JSON.parse(ajax.responseText);
                
                for (var i=0; i < arr.length; i++) {

                    var nazivGodine = arr[i].nazivGod;  
                    var vjezba = arr[i].nazivRepVje;
                    var spirala = arr[i].nazivRepSpi; 

                    var htmlDiv = document.createElement('div');
                    htmlDiv.className = 'godina';

                    htmlDiv.innerHTML = "Naziv godine: " + nazivGodine + "<br /> Naziv repozitorija vježbe: " + vjezba + "<br /> Naziv repozitorija spirale: " + spirala;

                    divSadrzaj.appendChild(htmlDiv);
                }
            }

            else if(ajax.readyState==4 && ajax.status== 404){
                document.getElementById("glavni").innerHTML="Error 404";
            }
        }
        ajax.open("GET","http://localhost:8080/godine" ,true);
        ajax.send();

        return {
            osvjezi:function()
            {
                ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    console.log(ajax.readyState);
                    if(ajax.readyState==4 && ajax.status==200){
                        
                        var arr = ajax.responseText;
                        
                        for (var i=0; i < arr.length(); i++) {

                            var nazivGodine = arr[i].nazivGod;  
                            var vjezba = arr[i].nazivRepVje;
                            var spirala = arr[i].nazivRepSpi; 

                            var htmlDiv = document.createElement('div');
                            htmlDiv.className = 'godina';

                            var tekst = document.createTextNode("Naziv godine: " + nazivGodine + "\n Naziv repozitorija vježbe: " + vjezba + "\n Naziv repozitorija spirale: " + spirala);
                            htmlDiv.appendChild(tekst);

                            divSadrzaj.appendChild(htmlDiv);
                        }
                    }

                    else if(ajax.readyState==4 && ajax.status== 404){
                        document.getElementById("glavni").innerHTML="Error 404";
                    }

                }
                ajax.open("GET","http://localhost:8080/godine" ,true);
                ajax.send();
            }
            
        }
    }
    return konstruktor;
}());

function fun()
{
    
    var divSadrzaj = document.getElementById("divSadrzaj");
    var kontainer = divSadrzaj.getElementsByClassName("grid-container")[0];
    var a = new GodineAjax(kontainer);

}
