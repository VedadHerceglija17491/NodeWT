var GodineAjax = (function() {
    var konstruktor = function(divSadrzaj) {
        var poziv = function() {
            var ajax = new XMLHttpRequest();
            
            ajax.onreadystatechange = function() {
                if(ajax.readyState == 4 && ajax.status == 200) {
                    var content = JSON.parse(ajax.responseText);
                    
                    if(content != []) {
                        var sadrzaj = "";
                        for(var i = 0; i < content.length; i++) {
                            var noviDiv = "<div class='divGodina'><p>nazivGod: " + content[i].nazivGod + "</p>";
                            noviDiv += "<p>nazivRepVje: " + content[i].nazivRepVje + "</p>";
                            noviDiv += "<p>nazivRepSpi: " + content[i].nazivRepSpi + "</p>";
                            noviDiv += "</div>";
                            sadrzaj += noviDiv;
                        }
                        divSadrzaj.innerHTML = sadrzaj;
                    }
                }
            }
    
            ajax.open('GET', 'http://localhost:8080/godine', true);
            ajax.send();
        }

        poziv();

        return {
            osvjezi: function() {
                poziv();
            }
        };
    };
    return konstruktor;
}());