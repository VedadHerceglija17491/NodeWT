function validiraj() {
    var forma = document.getElementById("noviZadatak");
    var inputNaziv = forma.getElementsByTagName("input")[0];
    var divGreske = document.getElementById("divGreske");
    var novo = Validacija(divGreske);
    novo.naziv(inputNaziv);
}

