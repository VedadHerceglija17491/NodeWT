var ZadaciAjax = (function(){
    var konstruktor = function(callbackFn){
        var xml = 0;
        var json = 0;
        var csv = 0;
        return {
            dajXML:function()
            {
                if(xml == 1 || json == 1 || csv == 1)
                {
                    callbackFn('{greska:"Već ste uputili zahtjev"}');
                }else
                {
                    xml = 1;
                    var ajax=new XMLHttpRequest();
                    ajax.onreadystatechange=function(){
                    
                    if(ajax.readyState==4 && ajax.status==200)
                    {
                        callbackFn(ajax.responseText);
                        xml = 0;
                    }
                    
                }
                ajax.open("GET","http://localhost:8080/zadaci" ,true);
                ajax.send();
                
                }
                
            },
            dajCSV:function()
            {
                if(xml == 1 || json == 1 || csv == 1)
                {
                    callbackFn('{greska:"Već ste uputili zahtjev"}');
                }else
                {
                    csv = 1;
                    var ajax=new XMLHttpRequest();
                    ajax.onreadystatechange=function(){
                    
                    if(ajax.readyState==4 && ajax.status==200)
                    {
                        callbackFn(ajax.responseText);
                        csv = 0;
                    }
                    
                }
                ajax.open("GET","http://localhost:8080/zadaci" ,true);
                ajax.send();
                ajax.setTimeout(() => {
                    
                }, 2000);
                }
            },
            dajJSON:function()
            {
                if(xml == 1 || json == 1 || csv == 1)
                {
                    callbackFn('{greska:"Već ste uputili zahtjev"}');
                }else
                {
                    json = 1;
                    var ajax=new XMLHttpRequest();
                    ajax.onreadystatechange=function(){
                    
                    if(ajax.readyState==4 && ajax.status==200)
                    {
                        callbackFn(ajax.responseText);
                        json = 0;
                    }
                    
                }
                ajax.open("GET","http://localhost:8080/zadaci" ,true);
                ajax.send();
                }
            }
        }
    }
    return konstruktor;
}());
    