const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const url = require('url');
const multer = require('multer');

// globals
const errPath = __dirname + '/public/views/greska.html';
const godinePath = './public/godine.csv';

var app = express();

var port = 8080;

app.use(express.static('public'));
app.use(express.static('public/views'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/zadaci/')
    },
    filename: function (req, file, cb) {
        cb(null, req.body['naziv'] + '.pdf')
    }
});

const upload = multer({ storage: storage });

app.get('/', function (req, res) {
    res.send("Hello world!");
});

app.post('/addZadatak', upload.single('postavka'), function (req, res) {
    const nazivZadatka = req.body['naziv'];

    fs.readFile('./public/zadaci/' + nazivZadatka + 'Zad.json', function (err, data) {
        if (err) {
            const zadatakJson = {
                naziv: nazivZadatka,
                postavka: `/zadaci/${nazivZadatka}.pdf`
            }
            fs.writeFile('./public/zadaci/' + nazivZadatka + 'Zad.json', JSON.stringify(zadatakJson), function (err) {
                if (err) {
                    res.sendFile(errPath);
                }
            });
            const noviZadatak = '\n' + nazivZadatka + ',' + zadatakJson.postavka;
            fs.appendFile('./public/zadaci/zadaci.csv', noviZadatak, function(err) {
                if(err) {
                    res.sendFile(errPath);
                } else {
                    res.redirect('/addZadatak.html');
                }
            });
        } else {
            res.sendFile(errPath);
        }
    });
});

app.get('/zadatak', function (req, res) {
    const naziv = req.query['naziv'];

    if (!naziv) {
        res.writeHead(404, 'No parameter provided!');
        res.end('No parameter provided!');
        return;
    }

    fs.readFile(`./public/zadaci/${naziv}Zad.json`, function(err, data) {
        if(err) {
            res.writeHead(404, 'Error reading file!');
            res.end('Requested file does not exist!');
            return;
        }
        const zadJson = JSON.parse(data);
        res.sendFile(__dirname + '/public' + zadJson.postavka);
    });
});

app.get('/zadaci', function(req, res) {
        const accepts = req.headers.accept;
        let priorityType = 'csv';
        if(accepts.indexOf('xml') > 0) {
            priorityType = 'xml';
        }
        if(accepts.indexOf('json') > 0) {
            priorityType = 'json';
        }
    
        fs.readFile('./public/zadaci/zadaci.csv', function(err, data) {
            if(err) {
                res.setHeader('Content-Type', 'application/json');
                res.write([]);
                return;
            }
            let jsonData = [];
            const rows = data.toString().split('\n');
            rows.forEach(function(row) {
                const columns = row.split(',');
                if(columns[0]) {
                    jsonData.push({naziv: columns[0], postavka: columns[1]});
                }
            });
            switch(priorityType) {
                case 'json': 
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify(jsonData));
                    return;
                case 'xml':
                    let xmlData = '<?xml version="1.0" encoding="UTF-8"?><zadaci>';
                    jsonData.forEach(function(zad) {
                        xmlData += `<zadatak>
                                        <naziv>${zad.naziv}</naziv>
                                        <postavka>${zad.postavka}</postavka>
                                    </zadatak>`;
                    });
                    xmlData += '</zadaci>';
                    res.setHeader('Content-Type', 'application/xml');
                    res.end(xmlData);
                    return;
                case 'csv': 
                    res.setHeader('Content-Type', 'text/csv');
                    res.end(data.toString());
                    return;
                default: 
                    res.setHeader('Content-Type', 'application/json');
                    res.write([]);
                    return;
            }
        });
});

app.post('/addGodina', function (req, res) {
    const nazivGod = req.body['nazivGod'];
    const nazivRepVje = req.body['nazivRepVje'];
    const nazivRepSpi = req.body['nazivRepSpi'];

    const addGodinaPath = __dirname + '/public/views/addGodina.html';

    if (!nazivGod || !nazivRepVje || !nazivRepSpi) {
        res.sendFile(errPath);
    } else {
        fs.readFile(godinePath, function (err, data) {
            if (err) {
                const newLine = '\n' + nazivGod + ',' + nazivRepVje + ',' + nazivRepSpi;
                fs.appendFile(godinePath, newLine, function (err) {
                    if (err) {
                        res.sendFile(errPath);
                    } else {
                        res.sendFile(addGodinaPath);
                    }
                });
            } else {
                let alreadyExists = false;
                const rows = data.toString().split('\n');
                rows.forEach(function (row) {
                    const columns = row.split(',');
                    const year = columns[0];
                    if (year === nazivGod) {
                        alreadyExists = true;
                    }
                });
                if (alreadyExists) {
                    res.sendFile(errPath);
                } else {
                    const newLine = '\n' + nazivGod + ',' + nazivRepVje + ',' + nazivRepSpi;
                    fs.appendFile(godinePath, newLine, function (err) {
                        if (err) {
                            res.sendFile(errPath);
                        } else {
                            res.sendFile(addGodinaPath);
                        }
                    });
                }
            }
        });
    }
});

app.get('/godine', function (req, res) {
    fs.readFile(godinePath, function (err, data) {
        if (err) {
            res.sendFile(errPath);
        } else {
            const rows = data.toString().split('\n');
            const jsonArray = [];
            rows.forEach(function (row) {
                const columns = row.split(',');
                jsonArray.push({
                    nazivGod: columns[0],
                    nazivRepVje: columns[1],
                    nazivRepSpi: columns[2]
                });
            });
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(jsonArray));
        }
    });
});

app.listen(port, function (err) {
    console.log('running server on port ' + port);
});