const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const accepts = require('accepts');
const multer = require('multer');
const pug = require('pug');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'zadaci/')
    },
    filename: function (req, file, cb) {
        cb(null, req.body.naziv+'.pdf')
    }
});

var upload = multer({ storage: storage });

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function (req, res) {
    res.send("nesto");
});

//DRUGI
app.post('/addZadatak', upload.single('postavka'), function (req, res) {
    const naz=req.body.naziv;
    fs.readFile('./zadaci/'+naz+'Zad.json', function(err,data){
        if(err)
        {
            const novi = {naziv:naz, postavka:'/zadaci/'+naz+'.pdf'};
            fs.writeFile('./zadaci/'+naz+'Zad.json', JSON.stringify(novi), function(err,data){
                if(err){
                    app.set('view engine', 'pug');
                    res.render('greska', {
                        name: 'upisu u fajl.'
                    });
                }
            });
            const str=naz+","+"/"+naz+".pdf\n";
           fs.appendFile('./zadaci/zadaci.txt', str, function(err,data){
               if(err){
                app.set('view engine', 'pug');
                res.render('greska', {
                    name: 'citanju .txt datoteke'
                });
               }
           });
           res.sendFile(__dirname + '/public/addZadatak.html');
        }
        else{
            app.set('view engine', 'pug');
                    res.render('greska', {
                        name: 'dodavanju zadatka. Taj naziv vec postoji!'
                    });
        }
    });
});

//TRECI
app.get('/zadatak', function (req, res) {
    const ime = req.query['naziv'];
    console.log(ime);
    if (!ime) {
        res.writeHead(404, 'Nema parametara');
        res.end('Nema parametara');
    }
    else {
        fs.readFile('./zadaci/'+ime+'Zad.json', function(err,data){
            if(err){return;}
            else{
                const json=JSON.parse(data);
                res.sendFile(__dirname +'/zadaci/'+ json.postavka);
            }
        });
        
    }
});

//CETVRTI
app.post('/addGodina', function (req, res) {
    const godina = req.body.nazivGod;
    const vjezba = req.body.nazivRepVje;
    const spirala = req.body.nazivRepSpi;
    if (!godina || !vjezba || !spirala) {
        app.set('view engine', 'pug');
        res.render('greska', {
            name: 'citanju podataka. Nesto niste unijeli.'
        });
    } else {
        const rec = godina + "," + vjezba + "," + spirala + "\n";
        fs.readFile('./public/godine.csv', function (err, data) {
            if (err) {
                fs.appendFile('./public/godine.csv', rec, function (err) {
                    if (err) {
                        app.set('view engine', 'pug');
                        res.render('greska', {
                            name: 'pri kreiranju .csv fajla.'
                        });
                    }
                    else {
                        res.sendFile(__dirname + '/public/addGodina.html');
                    }
                });
            }
            else {
                let bool = false;
                const rows = data.toString().split('\n');
                rows.forEach(function (row) {
                    const cols = row.split(',');
                    const god = cols[0];
                    if (god === godina) bool = true;
                });
                if (bool) {
                    app.set('view engine', 'pug');
                    res.render('greska', {
                        name: 'dodavanju godina. Takva vec postoji!'
                    });
                }
                else {
                    fs.appendFile('./public/godine.csv', rec, function (err) {
                        if (err) {
                            app.set('view engine', 'pug');
                            res.render('greska', {
                                name: 'dodavanju godine u .csv fajl.'
                            });
                        }
                        else res.sendFile(__dirname + '/public/addGodina.html');
                    });
                }
            }
        });
    }
});

//PETI
app.get('/godine', function (req, res) {
    fs.readFile('./public/godine.csv', function (err, data) {
        if (err) {
            app.set('view engine', 'pug');
            res.render('greska', {
                name: 'ocitavanju .csv fajla (jer ne postoji lol)'
            });
        }
        const rows = data.toString().split('\n');
        var result = [];
        rows.forEach(function (row) {
            const cols = row.split(',');
            if (cols[0] != "")
                result.push({ nazivGod: cols[0], nazivRepVje: cols[1], nazivRepSpi: cols[2] });
        });
        res.contentType('application/json');
        res.send(JSON.stringify(result));
        res.end();
    });
});

//SESTI JE GodineAjax.js

//SEDMI
app.get('/zadaci', function (req, res) {
    var accept = accepts(req);

    fs.readFile('./zadaci/zadaci.txt', function (err, data) {
        const rows = data.toString().split('\n');
        var result = [];
        switch (accept.type(['json', 'xml', 'csv'])) {
            case 'json':
                rows.forEach(function (row) {
                    const cols = row.split(',');
                    if (cols[0] != "")
                        result.push({ naziv: cols[0], postavka: cols[1] });
                });
                res.contentType('application/json');
                res.send(JSON.stringify(result));
                break;
            case 'xml':

                var rez = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
                rez += "<zadaci>";
                rows.forEach(function (row) {
                    const cols = row.split(',');
                    if (cols[0] != "") {
                        rez += "<zadatak>";
                        rez += "<naziv>" + cols[0] + "</naziv>"
                        rez += "<postavka>" + cols[1] + "</postavka>";
                        rez += "</zadatak>"
                    }
                });
                rez += "<zadaci>";
                res.set('Content-Type', 'application/xml');
                res.send(rez);
                break;
            case 'csv':
                var rez = "";
                rows.forEach(function (row) {
                    const cols = row.split(',');
                    if (cols[0] != "") {
                        rez += cols[0] + "," + cols[1] + "\n";
                    }
                });
                res.send(rez);
                break;
            default:
                app.set('view engine', 'pug');
                res.render('greska', {
                    name: 'ocitavanju vrijednosti headera.'
                });
                break;
        }

        res.end();
    });

});

//OSMI JE ZadaciAjax.js
app.listen(8080);