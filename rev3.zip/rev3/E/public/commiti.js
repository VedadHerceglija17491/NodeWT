window.onload=function(){
    var mojDiv=document.getElementById('mojDiv');

    const commit = document.getElementById('commit');
    const zadatak = document.getElementById('zadatak');;
    const url = document.getElementById('url');

    const dodaj = document.getElementById('dodaj');
    const edituj = document.getElementById('edituj');
    const obrisi = document.getElementById('obrisi');
    
    var tabela = new CommitTabela(mojDiv, 5);

    dodaj.addEventListener('click', function() {
        tabela.dodajCommit(Number(zadatak.value), url.value);
    });

    edituj.addEventListener('click', function() {
        tabela.editujCommit(Number(zadatak.value), Number(commit.value), url.value);
    });

    obrisi.addEventListener('click', function() {
        tabela.obrisiCommit(Number(zadatak.value), Number(commit.value));
    });
}