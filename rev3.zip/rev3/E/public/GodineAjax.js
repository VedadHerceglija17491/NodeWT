//SESTI
var GodineAjax = (function () {

    var konstruktor = function (divSadrzaj) {
        var nova=function(){
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var pom = xhttp.responseText;
                        xhttp = JSON.parse(pom);
                        const rows = xhttp.toString().split('\n');
                        xhttp.forEach(function (row) {
                            
                                var div = document.createElement('div');
                                div.innerHTML = row.nazivGod + "<br>" + row.nazivRepVje + "<br>" + row.nazivRepSpi + "<br>";
                                div.id = 'kockica';
                                divSadrzaj.appendChild(div);
                            
                        });


                    }
                };
                var url = "http://localhost:8080/godine";
                xhttp.open("GET", url, true);
                xhttp.send();
        }
        nova();
        return {
            osvjezi: nova
        }
    }
    
    return konstruktor;
}());
