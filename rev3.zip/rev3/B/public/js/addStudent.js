window.onload = function() {
    const form = document.getElementsByName('fPojedinacni')[0];
    form.onsubmit = function(event) {
        event.preventDefault();
    }
}
function klik() {
    var porukeDiv = document.getElementById('poruke');
    var ime = document.getElementsByName('ime')[0];
    var index = document.getElementsByName('index')[0];

    var validacija = new Validacija(porukeDiv);

    validacija.ime(ime);
    validacija.index(index);
};