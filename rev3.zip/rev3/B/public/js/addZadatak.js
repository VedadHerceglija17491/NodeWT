window.onload = function() {
    var porukeDiv = document.getElementById('poruke');
    var naziv = document.getElementsByName('naziv')[0];

    var validacija = new Validacija(porukeDiv);

    const form = document.getElementById('forma');
    form.onsubmit = function() {
        validacija.naziv(naziv);
        const isValid = checkIfValid([naziv]);
        return isValid;
    }

    function checkIfValid(inputs) {
        let valid = true;
        inputs.forEach(input => {
            if(input.style.backgroundColor === 'orangered'){
                valid = false;
            }
        });
        return valid;
    }
}