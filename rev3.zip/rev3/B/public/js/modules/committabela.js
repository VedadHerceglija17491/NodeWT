var CommitTabela = (function () {
    let tabela = '';
    var matrica = [];
    var konstruktor = function (divElement, brojZadataka) {

        for(i = 0; i < brojZadataka; i++){
            matrica.push([]);
        }

        function findMax(matrica) {
            if(matrica.length > 0) {
                let max = matrica[0].length;
                for(i = 0; i < matrica.length; i++) {
                    if(matrica[i].length > max) {
                        max = matrica[i].length;
                    }
                }
                return max;
            }
            return 0;
        }

        function createTable(matrica) {
            const max = findMax(matrica);
            tabela = '';
            tabela += '<table><tr><th>Naziv zadatka</th><th colspan="' + max + '">Commiti</th></tr>';
            for(i = 0; i < brojZadataka; i++) {
                tabela += '<tr><td>Zadatak ' + (i + 1) +'</td>';

                if(matrica[i].length === 0){
                    tabela += '<td colspan="'+max+'"></td>';
                } else {
                    for(j = 0; j < matrica[i].length; j++) {
                        tabela += '<td><a href="' + matrica[i][j].url +'">'+ matrica[i][j].rbCommita +'</a></td>'; 
                    }
                    if(matrica[i].length < max){
                        tabela += '<td colspan="'+(max - matrica[i].length)+'"></td>';
                    }
                }
                tabela += '</tr>';
            }
            tabela += '</table>'
    
            divElement.innerHTML = tabela;
        }
        createTable(matrica);

        var dodajCommit = function (rbZadatka, url) {
            if(rbZadatka < 0 || rbZadatka >= matrica.length) {
                return -1;
            }
            let redniBroj = 1;
            if(matrica[rbZadatka].length > 0) {
                const posljednji = matrica[rbZadatka].length - 1;
                redniBroj = matrica[rbZadatka][posljednji].rbCommita + 1;
            }
            matrica[rbZadatka].push({rbCommita: redniBroj, url: url});
            createTable(matrica);
        }

        var editujCommit = function (rbZadatka, rbCommita, url) {
            if(rbZadatka < 0 || rbZadatka >= matrica.length || rbCommita < 0 || rbCommita >= matrica[rbZadatka].length) {
                return -1;
            } 
            matrica[rbZadatka][rbCommita].url = url;
            createTable(matrica);
        }

        var obrisiCommit = function (rbZadatka, rbCommita) {
            if(rbZadatka < 0 || rbZadatka >= matrica.length || rbCommita < 0 || rbCommita >= matrica[rbZadatka].length) {
                return -1;
            }
            matrica[rbZadatka].splice(rbCommita, 1);
            createTable(matrica);   
        }

        return {
            dodajCommit: dodajCommit,
            editujCommit: editujCommit,
            obrisiCommit: obrisiCommit
        }
    }
    return konstruktor;
}());