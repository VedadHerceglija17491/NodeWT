window.onload = function() {
    const divSadrzaj = document.getElementById('glavniSadrzaj');
    const godineAjax = new GodineAjax(divSadrzaj);
    
    const form = document.getElementsByTagName('form')[0];

    form.onsubmit = function() {
        var porukeDiv = document.getElementById('poruke');
        var nazivGodine = document.getElementsByName('nazivGod')[0];
        var repoVjezbe = document.getElementsByName('nazivRepVje')[0];
        var repoSpirala = document.getElementsByName('nazivRepSpi')[0];
    
        var validacija = new Validacija(porukeDiv);
        const regex = /^[a-z]{1,}$/;
    
        validacija.godina(nazivGodine);
        validacija.repozitorij(repoVjezbe, regex);
        validacija.repozitorij(repoSpirala, regex);

        const isValid = checkIfValid([nazivGodine, repoVjezbe, repoSpirala]);
        return isValid;
    }

    function checkIfValid(inputs) {
        let valid = true;
        inputs.forEach(input => {
            if(input.style.backgroundColor === 'orangered'){
                valid = false;
            }
        });
        return valid;
    }

}
